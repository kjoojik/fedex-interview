import SearchPage from "../integration/PageObject/SearchPage";
import CommonResultsPage from "../integration/PageObject/CommonResultsPage";

describe('empty spec', () => {
  it('passes', () => {
    const search = new SearchPage();
	const commonResults = new CommonResultsPage();
	search.navigate();
	search.switchToSearching('planets');
	search.enterSearchPhrase('blabla')
	search.submit()
	commonResults.assertNotFound();
})
})