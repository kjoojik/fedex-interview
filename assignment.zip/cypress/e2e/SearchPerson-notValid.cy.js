import PersonsPage from "../integration/PageObject/PersonsPage";
import SearchPage from "../integration/PageObject/SearchPage"
import CommonResultsPage from "../integration/PageObject/CommonResultsPage"


describe('empty spec', () => {
  it('passes', () => {
    const search = new SearchPage();
	const commonResults = new CommonResultsPage();
	search.navigate();
	search.enterSearchPhrase('Lbla blabla');
	search.submit();
	commonResults.assertNotFound();

})
})