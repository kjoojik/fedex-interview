class PersonsPage {
    assertGenderLabel(label) {
        cy.get('#gender-label')	
		.should('have.text', label)
		.invoke('text')
		.then((s) => {
		    expect(s).to.string(label)
			 })
    }

    assertGenderValue(value) {
        cy.get('#gender-value')	
		.should('have.text', value)
		.invoke('text')
		.then((s) => {
			expect(s).to.string(value)
			})
    }

    assertBirthYearLabel(label) {
        cy.get('#Birth-year-label')	
		.should('have.text', label)
		.invoke('text')
		.then((s) => {
		    expect(s).to.string(label)
			 })
    }

    assertBirthYearValue(value) {
        cy.get('#Birth-year-value')	
		.should('have.text', value)
		.invoke('text')
		.then((s) => {
			expect(s).to.string(value)
			})
    }

    assertEyeColorLabel(label) {
        cy.get('#Eye-color-label')	
		.should('have.text', label)
		.invoke('text')
		.then((s) => {
		    expect(s).to.string(label)
			 })
    }

    assertEyeColorValue(value){
        cy.get('#Eye-color-value')	
		.should('have.text', value)
		.invoke('text')
		.then((s) => {
			expect(s).to.string(value)
			})
    }
    
    assertSkinColorLabel(label) {
        cy.get('#Skin-color-label')	
		.should('have.text', label)
		.invoke('text')
		.then((s) => {
		    expect(s).to.string(label)
			 })
    }

    assertSkinColorValue(value) {        
	    cy.get('#Skin-color-value')	
        .should('have.text', value)
        .invoke('text')
        .then((s) => {
            expect(s).to.string(value)
        })
    }
}
export default PersonsPage