class CommonResultsPage {
    assertNotFound() {
    	cy.get('#not-found')	
		.should('have.text', 'Not found.')
		.invoke('text')
		.then((s) => {
		    expect(s).to.string('Not found.')
			 })
    }
}
export default CommonResultsPage