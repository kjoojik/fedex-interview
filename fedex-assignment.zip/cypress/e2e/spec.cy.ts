describe('empty spec', () => {
  it('passes', () => {
    cy.visit('http://localhost:4200/')
		.get('#query')
		.type('Luke Skywalker')
		.should('have.value', 'Luke Skywaler')
	cy.get('button[type="submit"]')
		.click()
  })
})