import PlanetsPage from "../integration/PageObject/PlanetsPage";
import SearchPage from "../integration/PageObject/SearchPage";


describe('empty spec', () => {
  it('passes', () => {
    const search = new SearchPage();
	const planets = new PlanetsPage();
	search.navigate();
	search.switchToSearching('planets');
	search.enterSearchPhrase('Hoth');
	search.submit();
	planets.assertPopulationLabel('Population:');
	planets.assertPopulationValue(' unknown ');
	planets.assertClimateLabel('Climate:');
	planets.assertClimateValue('frozen');
	planets.assertGravityLabel('Gravity');
	planets.assertGravityValue(' 1.1 standard ');
})
})