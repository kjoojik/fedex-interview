import PersonsPage from "../integration/PageObject/PersonsPage";
import SearchPage from "../integration/PageObject/SearchPage";

describe('Search Person Suite', () => {
  it('Valid search for a person', () => {
    const search = new SearchPage();
	const persons = new PersonsPage();
	search.navigate();
	search.enterSearchPhrase('Luke Skywalker');
	search.submit();
	persons.assertGenderLabel('Gender:');
	persons.assertGenderValue(' male ');
	persons.assertBirthYearLabel('Birth year:');
	persons.assertBirthYearValue(' 19BBY ');
	persons.assertEyeColorLabel('Eye color:');
	persons.assertEyeColorValue(' blue ');
	persons.assertSkinColorLabel('Skin color:');
	persons.assertSkinColorValue(' fair ');
})
})