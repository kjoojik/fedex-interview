class PlanetsPage {

assertPopulationLabel(label) {
    cy.get('#Population-label')	
    .should('have.text', label)
    .invoke('text')
    .then((s) => {
    expect(s).to.string(label)
     })
    }

assertPopulationValue(value) {
    cy.get('#Population-value')	
    .should('have.text', value)
    .invoke('text')
    .then((s) => {
        expect(s).to.string(value)
    })
}

assertClimateLabel(label) {
cy.get('#Climate-label')	
.should('have.text', label)
.invoke('text')
.then((s) => {
    expect(s).to.string(label)
     })
}

assertClimateValue(value) {    
    cy.get('#Climate-value')	
    .should('have.text', value)
    .invoke('text')
    .then((s) => {
        expect(s).to.string(value)
    })
}

assertGravityLabel(label) {
    cy.get('#Gravity-label')	
    .should('have.text', label)
    .invoke('text')
    .then((s) => {
        expect(s).to.string(label)
     })
}

assertGravityValue(value) {
    cy.get('#Gravity-value')	
    .should('have.text', value)
    .invoke('text')
    .then((s) => {
        expect(s).to.string(value)
    })
}
}
export default PlanetsPage   