class SearchPage {
    navigate () {
        cy.visit('http://localhost:4200')
    }

    enterSearchPhrase(phrase) {
        cy.get('#query')
	        .type(phrase)
		    .should('have.value', phrase)
        return this 
    }

    submit() {
        cy.get('button[type="submit"]')
		.click() 
    }
    switchToSearching(searchFor) {
        cy.get('label[for="'+searchFor+'"]')
		.click()
    }
}
export default SearchPage